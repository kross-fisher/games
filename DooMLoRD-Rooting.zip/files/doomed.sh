#!/system/bin/sh
#
# DooMing Script: Part 1
# Part of Easy Rooting Toolkit by DooMLoRD@XDA
#
echo "--- DooMing device!"
echo "--- Correcting permissions"
chmod 777 /data/local/tmp/doomed2
chmod 777 /data/local/tmp/busybox
chmod 777 /data/local/tmp/run_root_shell
echo "--- Running exploit"
/data/local/tmp/run_root_shell
exit
