#!/bin/sh
chmod u+x files/adb_mac
echo "---------------------------------------------------------------"
echo "	             Easy Rooting toolkit (v17.0)"
echo "                   created by DooMLoRD"
echo "                   \"pref_event exploit\""
echo "    Credits go to all those involved in making this possible!"
echo "---------------------------------------------------------------"
echo "  Special thanks to: the_laser, Bin4ry, fi01, hiikezoe, [NUT]"
echo "  and to all those who are contributing to our git tree!"
echo "       Sources: https://github.com/android-rooting-tools"
echo "---------------------------------------------------------------"
echo "            ported to Mac OS X by ChrisBoesing                 "
echo "---------------------------------------------------------------"
echo "[*] This script will:"
echo "      (1) root ur device using the pref_event exploit"
echo "      (2) install Busybox"
echo "      (3) install SU files"
echo "[*] Before u begin:"   
echo "      (1) make sure u have installed adb drivers for ur device"
echo "      (2) enable \"USB DEBUGGING\"" 
echo "            from (Menu\Settings\Developer Options)"
echo "      (3) enable \"UNKNOWN SOURCES\""
echo "            from (Menu\Settings\Security)"
echo "      (4) connect USB cable to PHONE and then connect to PC"
echo "      (5) skip \"PC Companion Software\" prompt on device"
echo "---------------------------------------------------------------"
echo "CONFIRM ALL THE ABOVE THEN"
sleep 1
echo "--- STARTING ----"
echo "--- WAITING FOR DEVICE"
files/adb_mac wait-for-device
echo "--- creating temporary directory"
files/adb_mac shell "cd /data/local && mkdir tmp"
echo "--- cleaning"
files/adb_mac shell "cd /data/local/tmp/ && rm *"
echo "--- pushing files"
files/adb_mac push files/doomed.sh /data/local/tmp/doomed.sh
files/adb_mac push files/doomed2 /data/local/tmp/.
files/adb_mac push files/run_root_shell /data/local/tmp/.
files/adb_mac push files/busybox /data/local/tmp/.
files/adb_mac push files/su /data/local/tmp/.
files/adb_mac push files/Superuser.apk /data/local/tmp/.
files/adb_mac shell chmod 777 /data/local/tmp/doomed.sh
files/adb_mac shell /data/local/tmp/doomed.sh
echo "--- cleaning"
files/adb_mac shell rm /data/local/tmp/*
echo "--- Please wait device is now rebooting"
files/adb_mac reboot
echo "ALL DONE!!!"